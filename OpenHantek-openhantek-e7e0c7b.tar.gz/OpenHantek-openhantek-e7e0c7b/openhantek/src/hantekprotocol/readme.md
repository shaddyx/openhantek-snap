# Content
This directory contains all Enums, Structs, Bit- and Byte values
that together composes the Hantek protocol (in different model variants).

# Namespace
Everything in here needs to be in the `Hantek` namespace.

# Dependency
Files in this directory may not depend on any other directories.
