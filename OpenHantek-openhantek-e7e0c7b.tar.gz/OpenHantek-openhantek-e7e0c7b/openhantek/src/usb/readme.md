# Content
This directory contains all USB Command structs, firmware upload and
USB transfer functionality.

# Dependency
Files in this directory should NOT depend on anything outside of this directory.
