Use the `fwget.sh` script to extract a firmware from a windows driver. 
The copyright belongs to Hantek.
