---
layout: default
---
## Software triggered devices like the 6022BE

   - Support 48, 24, 16, 8, 4, 2, 1 M and 500, 200, 100 k Hz samplerates. For the 6022 with modded firmware by [jhoenicke](https://github.com/rpcope1/Hantek6022API) 
   - Can detect rising or falling edge of the signal.
   - Note that the first few samples are dropped due to unstable/unusual reading.

